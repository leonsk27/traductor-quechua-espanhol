from flask import Flask, request, jsonify, send_file
from flask_cors import CORS
import subprocess
import os
import uuid
import whisper

from transformers import WhisperForConditionalGeneration, WhisperProcessor

from whisper_quechua_to_text import transcribe_audio_quechua
from google_text_quechua_to_spanish import translate_quechua_to_spanish

from whisper_spanish_to_text import transcribe_audio_spanish
from google_text_spanish_to_quechua import translate_spanish_to_quechua

from google_tts_spanish import text_to_speech_spanish
from google_tts_quechua import text_to_speech_quechua

from data_dictionary_quechua import refinar_text_quechua
from data_translator import traducir_quechua_a_espanol, traducir_espanol_a_quechua

import logging

logging.basicConfig(level=logging.INFO)

app = Flask(__name__)
CORS(app)

print("⏳ Cargando modelo Whisper...")
# processor = WhisperProcessor.from_pretrained("LastEngineer01/whisper-quechua")
# model = WhisperForConditionalGeneration.from_pretrained("LastEngineer01/whisper-quechua")
processor = WhisperProcessor.from_pretrained("LastEngineer01/whisper-quechua-v2")
model = WhisperForConditionalGeneration.from_pretrained("LastEngineer01/whisper-quechua-v2")
# processor = WhisperProcessor.from_pretrained("models/whisper/checkpoint-150")
# model = WhisperForConditionalGeneration.from_pretrained("models/whisper/checkpoint-150")
print("✅ Modelo Whisper cargado.")
print("⏳ Cargando modelo Whisper-medium...")
model_medium = whisper.load_model("medium")
print("✅ Modelo Whisper-medium cargado.")
UPLOAD_FOLDER = "uploads"
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

@app.route('/transcribe_quechua_to_spanish_text', methods=['POST'])
def transcribe_audio_and_translate_to_spanish():
    if 'file' not in request.files:
        return jsonify({"error": "No se encontró el archivo"}), 400

    file = request.files['file']
    if file.filename == '':
        return jsonify({"error": "Nombre de archivo vacío"}), 400

    try:
        file_id = uuid.uuid4().hex
        file_path = os.path.join(UPLOAD_FOLDER, f"{file_id}_{file.filename}")
        file.save(file_path)

        logging.info("🎙️ Transcribiendo...")
        transcription = transcribe_audio_quechua(file_path, processor, model)
        logging.info(f"📝 Transcripción obtenida: {transcription}")
        logging.info(f"📝 Refinando...")
        refined_transcription = refinar_text_quechua(transcription)
        if refined_transcription:
            refined_text_quechua = " ".join(refined_transcription)
            logging.info(f"✅ Texto refinado: {refined_text_quechua}")
        else:
            refined_text_quechua = transcription
            logging.info("⚠️ No se refinó el texto, se usará la transcripción original.")
        os.remove(file_path)
        logging.info("🌐 Traduciendo diccionario...")
        traduccion_diccionario = traducir_quechua_a_espanol(refined_text_quechua)
        logging.info(f"🌐 Traduccion diccionario obtenida: {traduccion_diccionario}")

        if traduccion_diccionario is not None:
            translated_text_final = traduccion_diccionario
        else:
            logging.info("⚠️ Sin coincidencia suficiente en diccionario. Usando Google Translate...")
            translated_text_final = translate_quechua_to_spanish(refined_text_quechua)
        return jsonify({
            "quechua_text": refined_text_quechua,
            "spanish_translation": translated_text_final
        })
    except Exception as e:
        return jsonify({"error": "Error general", "details": str(e)}), 500

@app.route('/parse_to_sound_spanish', methods=['POST'])
def parse_to_sound_spanish():
    data = request.json
    if not data or "text" not in data:
        return jsonify({"error": "Texto requerido"}), 400
    try:
        filename = text_to_speech_spanish(data["text"])
        return send_file(filename, as_attachment=True, download_name="audio_es.mp3")
    finally:
        if os.path.exists(filename):
            print("archivo guardado")


@app.route('/transcribe_spanish_to_quechua_text', methods=['POST'])
def transcribe_audio_and_translate_to_quechua():
    if 'file' not in request.files:
        return jsonify({"error": "No se encontró el archivo"}), 400

    file = request.files['file']
    if file.filename == '':
        return jsonify({"error": "Nombre de archivo vacío"}), 400

    try:
        file_id = uuid.uuid4().hex
        file_path = os.path.join(UPLOAD_FOLDER, f"{file_id}_{file.filename}")
        file.save(file_path)

        logging.info("🎙️ Transcribiendo (Español)...")
        transcription = transcribe_audio_spanish(file_path, model_medium)
        os.remove(file_path)
        logging.info("🌐 Traduciendo diccionario...")
        traduccion_diccionario = traducir_espanol_a_quechua(transcription)
        logging.info(f"🌐 Traduccion encontrada en diccionario: {traduccion_diccionario}")

        if traduccion_diccionario is not None:
            translated_text_final = traduccion_diccionario
        else:
            logging.info("⚠️ Sin coincidencia suficiente en diccionario. Usando Google Translate...")
            translated_text_final = translate_spanish_to_quechua(transcription)
        return jsonify({
            "spanish_text": transcription,
            "quechua_translation": translated_text_final
        })

    except Exception as e:
        logging.exception("❌ Error durante la transcripción o traducción:")
        return jsonify({"error": "Error general", "details": str(e)}), 500


@app.route('/parse_to_sound_quechua', methods=['POST'])
def parse_to_sound_quechua():
    data = request.json
    if not data or "text" not in data:
        return jsonify({"error": "Texto requerido"}), 400
    try:
        filename = text_to_speech_quechua(data["text"])
        return send_file(filename, as_attachment=True, download_name="audio_qu.mp3")
    finally:
        if os.path.exists(filename):
            print("archivo guardado")

if __name__ == '__main__':
    port = int(os.environ.get("PORT", 8080))
    app.run(host='0.0.0.0', port=port, debug=True)