import json
import requests
import os
from dotenv import load_dotenv

load_dotenv()

def get_api_key():
    try:
        with open("google_api_key.json") as f:
            data = json.load(f)
            return data["API_KEY"]
    except Exception:
        return os.getenv("API_KEY")

def translate_quechua_to_spanish(texto_quechua):
    API_KEY = get_api_key()
    if not API_KEY:
        raise RuntimeError("No se encontró una API_KEY válida")

    url = f"https://translation.googleapis.com/language/translate/v2?key={API_KEY}"
    data = {
        "q": texto_quechua,
        "source": "qu",
        "target": "es",
        "format": "text"
    }

    response = requests.post(url, json=data)
    if response.status_code == 200:
        return response.json()["data"]["translations"][0]["translatedText"]
    else:
        raise RuntimeError(f"Error de traducción (qu→es): {response.json()}")

def translate_spanish_to_quechua(texto_espanol):
    API_KEY = get_api_key()
    if not API_KEY:
        raise RuntimeError("No se encontró una API_KEY válida")

    url = f"https://translation.googleapis.com/language/translate/v2?key={API_KEY}"
    data = {
        "q": texto_espanol,
        "source": "es",
        "target": "qu",
        "format": "text"
    }

    response = requests.post(url, json=data)
    if response.status_code == 200:
        return response.json()["data"]["translations"][0]["translatedText"]
    else:
        raise RuntimeError(f"Error de traducción (es→qu): {response.json()}")
