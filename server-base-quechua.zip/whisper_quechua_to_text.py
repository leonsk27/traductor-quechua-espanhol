from transformers import WhisperForConditionalGeneration, WhisperProcessor
import librosa
import subprocess
import os
import uuid
import torch

def convert_to_wav(input_path):
    temp_wav = f"/tmp/temp_{uuid.uuid4().hex}.wav"
    subprocess.run(["ffmpeg", "-i", input_path, "-ar", "16000", temp_wav], check=True)
    return temp_wav

def transcribe_audio_quechua(file_path, processor, model):
    # Convertir si no es WAV
    if not file_path.lower().endswith(".wav"):
        print("🔄 Convirtiendo archivo a WAV...")
        file_path = convert_to_wav(file_path)

    audio_input, _ = librosa.load(file_path, sr=16000)
    inputs = processor(audio_input, sampling_rate=16000, return_tensors="pt")
    forced_decoder_ids = processor.get_decoder_prompt_ids(language="es", task="transcribe")

    with torch.no_grad():
        predicted_ids = model.generate(inputs.input_features, forced_decoder_ids=forced_decoder_ids)

    transcription = processor.batch_decode(predicted_ids, skip_special_tokens=True)[0]
    return transcription
